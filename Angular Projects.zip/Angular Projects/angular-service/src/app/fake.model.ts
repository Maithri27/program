export class Fake { // This class is use to map json data. 
    constructor(
        public userId:number,
        public id:number,
        public title:string,
        public completed:boolean){}
}