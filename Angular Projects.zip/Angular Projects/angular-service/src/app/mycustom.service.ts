
export class MyService {

    sayHello():string {
        return "Welcome to UserDefind service without DI";
    }
}