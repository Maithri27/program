export class Employee { // this class is use to map json data. 

    constructor(public id:number,public name:string,public salary:number){}

}